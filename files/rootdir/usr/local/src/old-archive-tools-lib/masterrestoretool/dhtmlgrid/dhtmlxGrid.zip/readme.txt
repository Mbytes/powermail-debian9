(c)Scand LLC, 2004-2006 dhtmlxGrid v.1.2 Standard Edition, built 61129

This software can be used under GNU GPL. To use it in non-GPL application 
please contact us to obtain Commercial/Enterprise license (Profession Edition included)

dhtmlx@scand.com
